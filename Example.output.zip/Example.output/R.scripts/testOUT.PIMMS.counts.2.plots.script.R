
# PIMMS counts output processing
inter.unique.insertion.dist <- read.table("testOUT.PIMMS.counts.min_cov.2.unique.insertion.inter.distances")
data1 <- inter.unique.insertion.dist[,1]
pdf("testOUT.PIMMS.counts.min_cov.2.inter.insertion.distances.density.plot.pdf")
d1 <- density(data1)
plot(d1, main="Kernal Density testOUT inter-insertion distance", lwd = 3, col=rgb(1,0,0,0.4), xlab = "Inter unique insertion distance (bp)")
dev.off()

unique.insertion.centile <- read.table("testOUT.PIMMS.counts.min_cov.2.unique.insertion.centile.positions")
data2 <- unique.insertion.centile[,1]
pdf("testOUT.PIMMS.counts.min_cov.2.unique.insertion.centile.positions.density.plot.pdf")
d2 <- density(data2)
plot(d2, main="Kernal Density testOUT unique insertion centile positions", lwd = 3, col=rgb(1,0,0,0.4), xlab = "Position centile")
dev.off()

read.depth <- read.table("testOUT.PIMMS.counts.min_cov.2.insertion.positions.depths", skip= 1, sep = '	', quote = "")
x <- read.depth[,1]
y <- read.depth[,2]
smoothingSpline = smooth.spline(x, y, spar=0.3)
pdf("testOUT.PIMMS.counts.min_cov.2.insertion.positions.depths.pdf")
plot (x,y , main = "testOUT insertion read depth", xlab = "Genome position", ylab = "Read Depth", xlim = c(1,1852352))
lines(smoothingSpline, col='green', lwd=2)
dev.off()

z <- read.depth[,3]
smoothingSpline = smooth.spline(x, z, spar=0.3)
pdf("testOUT.PIMMS.counts.min_cov.2.insertion.positions.NIindex.pdf")
plot (x,z, main = "testOUT NIindex (red line=expected count)", xlab = "Genome position", ylab = "NIindex", xlim = c(1,1852352))
lines(smoothingSpline, col='green', lwd=2)
abline(h=6.14702837026299,col='red',lty=2, lwd=2)
dev.off()

upper_bound <- 5 * 6.14702837026299
lower_bound <- -1*(5 * 6.14702837026299)
pdf("testOUT.PIMMS.counts.min_cov.2.insertion.positions.NIindex.Zoom.pdf")
plot (x,z, main = "testOUT NIindex (red line=expected count)", xlab = "Genome position", ylab = "NIindex", xlim = c(1,1852352), ylim = c(lower_bound,upper_bound))
lines(smoothingSpline, col='green', lwd=2)
abline(h=6.14702837026299,col='red',lty=2, lwd=2)
dev.off()


read.depth <- read.table("testOUT.PIMMS.counts.min_cov.2.insertion.positions.depths", skip= 1, sep = '	', quote = "")
x <- read.depth[,1]
y1 <- read.depth[,5]
smoothingSpline = smooth.spline(x, y1, spar=0.1)
pdf("testOUT.PIMMS.counts.min_cov.2.insertion.positions.NIPdiff.pdf")
plot (x,y1, main = "testOUT NIPdiff (red line=expected proportion)", xlab = "Genome position", ylab = "Normalised insertion proportion (NIPdiff)", xlim = c(1,1852352))
lines(smoothingSpline, col='green', lwd=2)
abline(h=0.00020708221163802,col='red',lty=2, lwd=2)
dev.off()

upper_bound <- 5  *0.00020708221163802
lower_bound <- -1*(5 * 0.00020708221163802)
pdf("testOUT.PIMMS.counts.min_cov.2.insertion.positions.NIPdiff.zoom.pdf")
plot (x,y1, main = "testOUT NIPdiff (red line=expected proportion)", xlab = "Genome position", ylab = "Normalised insertion proportion (NIPdiff)", xlim = c(1,1852352), ylim = c(lower_bound,upper_bound))
lines(smoothingSpline, col='green', lwd=2)
abline(h=0.00020708221163802,col='red',lty=2, lwd=2)
dev.off()


read.depth <- read.table("testOUT.PIMMS.counts.min_cov.2.insertion.positions.depths", skip= 1, sep = '	', quote = "")
x <- read.depth[,1]
y2 <- read.depth[,6]
smoothingSpline = smooth.spline(x, y2, spar=0.1)
pdf("testOUT.PIMMS.counts.min_cov.2.insertion.positions.NIPratio.pdf")
plot (x,y2, main = "testOUT NIPratio (red line=expected proportion)", xlab = "Genome position", ylab = "Normalised insertion proportion (NIPratio)", xlim = c(1,1852352))
lines(smoothingSpline, col='green', lwd=2)
abline(h=0.00020708221163802,col='red',lty=2, lwd=2)
dev.off()

upper_bound <- 10
lower_bound <- 0
pdf("testOUT.PIMMS.counts.min_cov.2.insertion.positions.NIPratio.zoom.pdf")
plot (x,y2, main = "testOUT NIPratio (red line=expected proportion)", xlab = "Genome position", ylab = "Normalised insertion proportion (NIPratio)", xlim = c(1,1852352), ylim = c(lower_bound,upper_bound))
lines(smoothingSpline, col='green', lwd=2)
abline(h=0.00020708221163802,col='red',lty=2, lwd=2)
dev.off()

# distributions of NRM & NIM scores
summary.in <- read.table("testOUT.PIMMS.counts.min_cov.2.summary.table", header = TRUE, sep = '	', na.strings = "NA", quote = "")
NRM <- summary.in[,12]
NIM <- summary.in[,13]
logNRM <- log(NRM)
logNIM <- log(NIM)
d3 <- density(NRM)
d4 <- density(NIM)
pdf("testOUT.PIMMS.counts.min_cov.2.summary.plots.pdf")
par(mfrow=c(2,2))
plot(d3, main="Kernal Density testOUT NRM", lwd = 3, col=rgb(1,0,0,0.4), xlab = "NRM")
plot(d4, main="Kernal Density testOUT NIM", lwd = 3, col=rgb(1,0,0,0.4), xlab = "NIM")
hist(logNRM, col=rgb(1,0,0,0.4), main="natural log transformed NRM", border = rgb(1,0,0,0.4))
hist(logNIM, col=rgb(1,0,0,0.4), main="natural log transformed NIM", border = rgb(1,0,0,0.4))
dev.off()


